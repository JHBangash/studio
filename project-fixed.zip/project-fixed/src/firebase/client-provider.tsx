'use client';

import { useState, useEffect } from 'react';
import { getFirebase } from '@/firebase';
import { FirebaseProvider } from '@/firebase/provider';
import type { FirebaseApp } from 'firebase/app';
import type { Auth } from 'firebase/auth';
import type { Firestore } from 'firebase/firestore';
import { Loader2 } from 'lucide-react';

export function FirebaseClientProvider({
  children,
}: {
  children: React.ReactNode;
}) {
  const [firebase, setFirebase] = useState<{
    app: FirebaseApp;
    auth: Auth;
    firestore: Firestore;
  } | null>(null);
  const [initialized, setInitialized] = useState(false);

  useEffect(() => {
    const services = getFirebase();
    if (!services) {
      console.warn('Firebase could not be initialized. Check your environment variables.');
    } else {
      setFirebase(services);
    }
    setInitialized(true);
  }, []);

  if (!initialized) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="w-12 h-12 animate-spin text-primary" />
      </div>
    );
  }

  if (!firebase) {
    return (
      <div className="flex items-center justify-center min-h-screen flex-col gap-4">
        <p className="text-destructive font-semibold">Firebase connection failed.</p>
        <p className="text-muted-foreground text-sm">Please check your environment variables (NEXT_PUBLIC_FIREBASE_*).</p>
      </div>
    );
  }

  return (
    <FirebaseProvider app={firebase.app} auth={firebase.auth} firestore={firebase.firestore}>
      {children}
    </FirebaseProvider>
  );
}
